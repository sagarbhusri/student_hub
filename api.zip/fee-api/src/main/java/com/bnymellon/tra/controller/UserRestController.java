package com.bnymellon.tra.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bnymellon.tra.daoImpl.UserAccountDaoImpl;
import com.bnymellon.tra.model.UserAccount;

@RestController
public class UserRestController {
   @Autowired
	private UserAccountDaoImpl dao;
	private int ResponseEntity;
	
	@GetMapping("/users")
	public List<UserAccount> getAllUser()
	{
		return dao.getAllUser();
	}
	
	@GetMapping("/users/{id}")
	public ResponseEntity<Object> getUser (@PathVariable("id") String id){
		UserAccount e=dao.getUserById(id);
		return new ResponseEntity<Object>(e,HttpStatus.OK); 
	}

	 @PostMapping(value = "/users")
	    public ResponseEntity<Object> insertEmployee(@RequestBody UserAccount u) {
	         dao.save(u);
	          return new ResponseEntity<Object>(u, HttpStatus.OK);
	    }
	 
	 @DeleteMapping("/users/{id}")
	    public ResponseEntity<Object> deleteEmployee(@PathVariable String id) {
	         dao.delete(id);
	          return new ResponseEntity<Object>("User deleted with ID " + id, HttpStatus.OK);
	    }
	
	 @PutMapping("/users/{id}")
	    public ResponseEntity<Object> updateEmployee(@PathVariable String id, @RequestBody UserAccount u) {
	         dao.update(id, u);
	          return new ResponseEntity<Object>("User udpated with ID " + id, HttpStatus.OK);
	    }
}
