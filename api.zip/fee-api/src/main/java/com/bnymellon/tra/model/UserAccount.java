package com.bnymellon.tra.model;

import java.sql.Date;

public class UserAccount {

	private String userId;
	private String userRole;
	private String userFirstName;
	private String userLastName;
	private String userContactNumber;
	private String userEmail;
	private String userGender;
	private Date userDateOfBirth;
	private int userBatch;
	private String userStream;
	private String userAddress;
	private String userCurrentAddress;
	private Date userDateOfJoining;
	private String userIsHostel;
	private String userIsDayScholar;
	private String userPassword;
	
	public UserAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserAccount(String userId, String userRole, String userFirstName,
			String userLastName, String userContactNumber, String userEmail,
			String userGender, Date userDateOfBirth, int userBatch,
			String userStream, String userAddress, String userCurrentAddress,
			Date userDateOfJoining, String userIsHostel,
			String userIsDayScholar, String userPassword) {
		super();
		this.userId = userId;
		this.userRole = userRole;
		this.userFirstName = userFirstName;
		this.userLastName = userLastName;
		this.userContactNumber = userContactNumber;
		this.userEmail = userEmail;
		this.userGender = userGender;
		this.userDateOfBirth = userDateOfBirth;
		this.userBatch = userBatch;
		this.userStream = userStream;
		this.userAddress = userAddress;
		this.userCurrentAddress = userCurrentAddress;
		this.userDateOfJoining = userDateOfJoining;
		this.userIsHostel = userIsHostel;
		this.userIsDayScholar = userIsDayScholar;
		this.userPassword = userPassword;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getUserContactNumber() {
		return userContactNumber;
	}

	public void setUserContactNumber(String userContactNumber) {
		this.userContactNumber = userContactNumber;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserGender() {
		return userGender;
	}

	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}

	public Date getUserDateOfBirth() {
		return userDateOfBirth;
	}

	public void setUserDateOfBirth(Date userDateOfBirth) {
		this.userDateOfBirth = userDateOfBirth;
	}

	public int getUserBatch() {
		return userBatch;
	}

	public void setUserBatch(int userBatch) {
		this.userBatch = userBatch;
	}

	public String getUserStream() {
		return userStream;
	}

	public void setUserStream(String userStream) {
		this.userStream = userStream;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getUserCurrentAddress() {
		return userCurrentAddress;
	}

	public void setUserCurrentAddress(String userCurrentAddress) {
		this.userCurrentAddress = userCurrentAddress;
	}

	public Date getUserDateOfJoining() {
		return userDateOfJoining;
	}

	public void setUserDateOfJoining(Date userDateOfJoining) {
		this.userDateOfJoining = userDateOfJoining;
	}

	public String getUserIsHostel() {
		return userIsHostel;
	}

	public void setUserIsHostel(String userIsHostel) {
		this.userIsHostel = userIsHostel;
	}

	public String getUserIsDayScholar() {
		return userIsDayScholar;
	}

	public void setUserIsDayScholar(String userIsDayScholar) {
		this.userIsDayScholar = userIsDayScholar;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	@Override
	public String toString() {
		return "UserAccount [userId=" + userId + ", userRole=" + userRole
				+ ", userFirstName=" + userFirstName + ", userLastNmae="
				+ userLastName + ", userContactNumber=" + userContactNumber
				+ ", userEmail=" + userEmail + ", userGender=" + userGender
				+ ", userDateOfBirth=" + userDateOfBirth + ", userBatch="
				+ userBatch + ", userStream=" + userStream + ", userAddress="
				+ userAddress + ", userCurrentAddress=" + userCurrentAddress
				+ ", userDateOfJoining=" + userDateOfJoining
				+ ", userIsHostel=" + userIsHostel + ", userIsDayScholar="
				+ userIsDayScholar + ", userPassword=" + userPassword + "]";
	}
	
	
	
}
