package com.bnymellon.tra.dao;

import java.sql.SQLException;
import java.util.List;

import com.bnymellon.tra.model.UserAccount;

public interface UserAccountDao {
	
	public int save(UserAccount user);
	public int update( String searchById, UserAccount user);
	public int delete(String searchById);
	public UserAccount getUserById(String id);
	public  List<UserAccount> getAllUser() throws SQLException;
	
}
