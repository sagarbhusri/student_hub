package com.bnymellon.tra.daoImpl;

import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.bnymellon.tra.dao.UserAccountDao;
import com.bnymellon.tra.model.UserAccount;
import com.bnymellon.tra.utils.UserRowMapper;

public class UserAccountDaoImpl implements UserAccountDao {
	
	private JdbcTemplate template;

	public UserAccountDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	public int save(UserAccount user){
		String dateOfBirth = new SimpleDateFormat("dd-MMM-yy").format(user.getUserDateOfBirth());

        String dateOfJoining = new SimpleDateFormat("dd-MMM-yy").format(user.getUserDateOfJoining());


		
		String sql = "insert into XBBNHM0_users_api values ('" + user.getUserId()
				+ "','" +user.getUserRole()+ "','"+user.getUserFirstName() + "','"
				+ user.getUserLastName() + "','" + user.getUserContactNumber() + "','"
				+ user.getUserEmail() + "','" + user.getUserGender() + "','"
				+ dateOfBirth + "','"
				+ user.getUserBatch() + "','" + user.getUserStream() + "','"
				+ user.getUserAddress() + "','" + user.getUserCurrentAddress() + "','" + dateOfJoining
				+ "','" + user.getUserIsHostel() + "','"
				+ user.getUserIsDayScholar() + "','" + user.getUserPassword()
				+ "')";
		return template.update(sql);
		
		
	}
	
	
	public int update( String searchById, UserAccount user){
		System.out.println(user.getUserDateOfJoining());
		String dateOfBirth = new SimpleDateFormat("dd-MMM-yy").format(user.getUserDateOfBirth());

        String dateOfJoining = new SimpleDateFormat("dd-MMM-yy").format(user.getUserDateOfJoining());

        System.out.println(dateOfBirth);
        System.out.println(dateOfJoining);
		
		String sql = "UPDATE XBBNHM0_USERS_API SET userId='"+user.getUserId()+"',userRole='" +user.getUserRole()+ "',userFirstName= '"+user.getUserFirstName() + "',userLastName='"
				+ user.getUserLastName() + "',userContact='" + user.getUserContactNumber() + "', userMail='"
				+ user.getUserEmail() + "',userGender='" + user.getUserGender() + "',userDateOfBirth='"
				+ dateOfBirth + "', userBatch='"
				+ user.getUserBatch() + "',userStream='" + user.getUserStream() + "',userAddress='"
				+ user.getUserAddress() + "',userCurrentAddress='" + user.getUserCurrentAddress() + "',userDateOfJoining='" + dateOfJoining
				+ "',userIsHostel='" + user.getUserIsHostel() + "' ,userIsDayScholar='"
				+ user.getUserIsDayScholar() + "'where userId='" + searchById +"'";
						
					
		return template.update(sql);
		
		
	}

	public int delete(String searchById){
		String sql="delete from XBBNHM0_users_api where userId='" + searchById +"'";
		return template.update(sql);
	}
	
	
	public UserAccount getUserById(String id){
		String sql="select * from XBBNHM0_users_api where userId='" + id+"'";
		UserAccount found =null;
		found =template.queryForObject(sql, new UserRowMapper());
		System.out.println(found);
		return found;
	}
	

	public List<UserAccount> getAllUser() {
		List<UserAccount> all = null;
		String sql = "select * from XBBNHM0_users_api";

		all = template.query(sql, new UserRowMapper());

		return all;
	}
	
}

